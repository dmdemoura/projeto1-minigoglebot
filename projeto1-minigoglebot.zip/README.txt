        Projeto Mini Googlebot (Parte 1)

Integrantes do grupo:
    Gyovana Mayara Moriyama, NºUSP: 10734387
    Gabriel de Moura Peres, NºUSP: 10734522
    Henrique Matarazo Camillo, NºUSP: 10294943
 
Compilador utilizado: gcc
Plataforma utilizada: Linux

Modo de usar:
O programa exibirá na tela as informações necessárias para uso do programa.

Para a implementação do programa, foi feito uso de Listas Lineares Encadeadas Ordenadas Dinâmicas. Esse tipo de esturutra de dados foi escolhido para facilitar a remoção e inserção de sites (não sendo necessária a movimentação de elementos, como num vetor), já que essa é uma funcionalidade recorrente no programa. Além disso, ela possibilita a criação de uma lista expansível, ou seja, que não possui um limite de sites que consegue armazenar. Ao final do uso do programa, ele salva os dados num arquivo .csv.
