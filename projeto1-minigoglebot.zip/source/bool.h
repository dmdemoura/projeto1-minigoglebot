#ifndef BOOL_H
#define BOOL_H

#define TRUE 1
#define FALSE 0
typedef int bool;

#endif